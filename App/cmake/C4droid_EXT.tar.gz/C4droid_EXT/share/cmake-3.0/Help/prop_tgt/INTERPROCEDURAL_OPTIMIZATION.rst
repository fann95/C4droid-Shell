INTERPROCEDURAL_OPTIMIZATION
----------------------------

Enable interprocedural optimization for a target.

If set to true, enables interprocedural optimizations if they are
known to be supported by the compiler.
