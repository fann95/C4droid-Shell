ARCHIVE_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: ARCHIVE
.. |xxx| replace:: archive
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: CMAKE_ARCHIVE_OUTPUT_DIRECTORY
.. include:: XXX_OUTPUT_DIRECTORY.txt
