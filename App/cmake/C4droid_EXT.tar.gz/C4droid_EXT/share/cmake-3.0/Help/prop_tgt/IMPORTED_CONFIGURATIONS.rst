IMPORTED_CONFIGURATIONS
-----------------------

Configurations provided for an IMPORTED target.

Set this to the list of configuration names available for an IMPORTED
target.  The names correspond to configurations defined in the project
from which the target is imported.  If the importing project uses a
different set of configurations the names may be mapped using the
MAP_IMPORTED_CONFIG_<CONFIG> property.  Ignored for non-imported
targets.
