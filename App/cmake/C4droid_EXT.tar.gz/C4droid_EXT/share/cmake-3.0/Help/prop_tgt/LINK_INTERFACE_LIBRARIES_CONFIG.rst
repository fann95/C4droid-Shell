LINK_INTERFACE_LIBRARIES_<CONFIG>
---------------------------------

Per-configuration list of public interface libraries for a target.

This is the configuration-specific version of
LINK_INTERFACE_LIBRARIES.  If set, this property completely overrides
the generic property for the named configuration.

This property is overridden by the INTERFACE_LINK_LIBRARIES property if
policy CMP0022 is NEW.

This property is deprecated.  Use INTERFACE_LINK_LIBRARIES instead.
