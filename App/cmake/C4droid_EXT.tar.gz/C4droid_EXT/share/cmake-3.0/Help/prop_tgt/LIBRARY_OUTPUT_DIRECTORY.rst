LIBRARY_OUTPUT_DIRECTORY
------------------------

.. |XXX| replace:: LIBRARY
.. |xxx| replace:: library
.. |CMAKE_XXX_OUTPUT_DIRECTORY| replace:: CMAKE_LIBRARY_OUTPUT_DIRECTORY
.. include:: XXX_OUTPUT_DIRECTORY.txt
