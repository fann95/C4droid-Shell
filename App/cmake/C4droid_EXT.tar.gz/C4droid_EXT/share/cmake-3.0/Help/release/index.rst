CMake Release Notes
*******************

..
  This file should include the adjacent "dev.txt" file
  in development versions but not in release versions.

Releases
========

.. toctree::
   :maxdepth: 1

   3.0.0 <3.0.0>
