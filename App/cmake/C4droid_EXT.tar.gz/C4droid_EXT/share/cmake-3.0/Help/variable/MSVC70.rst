MSVC70
------

True when using Microsoft Visual C 7.0

Set to true when the compiler is version 7.0 of Microsoft Visual C.
