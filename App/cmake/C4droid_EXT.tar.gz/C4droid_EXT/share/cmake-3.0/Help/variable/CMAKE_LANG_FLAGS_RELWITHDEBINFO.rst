CMAKE_<LANG>_FLAGS_RELWITHDEBINFO
---------------------------------

Flags for RelWithDebInfo type or configuration.

<LANG> flags used when CMAKE_BUILD_TYPE is RelWithDebInfo.  Short for
Release With Debug Information.
