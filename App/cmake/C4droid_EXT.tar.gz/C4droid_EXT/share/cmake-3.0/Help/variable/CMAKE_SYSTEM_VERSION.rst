CMAKE_SYSTEM_VERSION
--------------------

OS version CMake is building for.

A numeric version string for the system, on systems that support
uname, this variable is set to the output of uname -r.  On other
systems this is set to major-minor version numbers.
