CMAKE_EDIT_COMMAND
------------------

Full path to cmake-gui or ccmake.  Defined only for Makefile generators
when not using an "extra" generator for an IDE.

This is the full path to the CMake executable that can graphically
edit the cache.  For example, cmake-gui or ccmake.
