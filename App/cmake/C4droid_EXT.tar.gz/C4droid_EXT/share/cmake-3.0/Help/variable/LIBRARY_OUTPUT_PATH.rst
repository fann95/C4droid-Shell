LIBRARY_OUTPUT_PATH
-------------------

Old library location variable.

The target properties ARCHIVE_OUTPUT_DIRECTORY,
LIBRARY_OUTPUT_DIRECTORY, and RUNTIME_OUTPUT_DIRECTORY supercede this
variable for a target if they are set.  Library targets are otherwise
placed in this directory.
