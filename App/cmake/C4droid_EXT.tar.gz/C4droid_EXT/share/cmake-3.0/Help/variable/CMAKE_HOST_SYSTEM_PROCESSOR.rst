CMAKE_HOST_SYSTEM_PROCESSOR
---------------------------

The name of the CPU CMake is running on.

The same as CMAKE_SYSTEM_PROCESSOR but for the host system instead of
the target system when cross compiling.
