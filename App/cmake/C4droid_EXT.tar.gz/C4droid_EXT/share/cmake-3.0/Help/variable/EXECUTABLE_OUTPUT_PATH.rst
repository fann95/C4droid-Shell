EXECUTABLE_OUTPUT_PATH
----------------------

Old executable location variable.

The target property RUNTIME_OUTPUT_DIRECTORY supercedes this variable
for a target if it is set.  Executable targets are otherwise placed in
this directory.
