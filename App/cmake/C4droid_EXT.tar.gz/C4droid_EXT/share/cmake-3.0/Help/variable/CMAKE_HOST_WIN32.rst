CMAKE_HOST_WIN32
----------------

True on windows systems, including win64.

Set to true when the host system is Windows and on Cygwin.
