MSVC_IDE
--------

True when using the Microsoft Visual C IDE

Set to true when the target platform is the Microsoft Visual C IDE, as
opposed to the command line compiler.
