CMAKE_CTEST_COMMAND
-------------------

Full path to ctest command installed with cmake.

This is the full path to the CTest executable ctest which is useful
from custom commands that want to use the cmake -E option for portable
system commands.
