CMAKE_HOST_SYSTEM_VERSION
-------------------------

OS version CMake is running on.

The same as CMAKE_SYSTEM_VERSION but for the host system instead of
the target system when cross compiling.
