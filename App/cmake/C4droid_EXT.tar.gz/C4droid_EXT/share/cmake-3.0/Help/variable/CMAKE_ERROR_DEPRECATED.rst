CMAKE_ERROR_DEPRECATED
----------------------

Whether to issue deprecation errors for macros and functions.

If TRUE, this can be used by macros and functions to issue fatal
errors when deprecated macros or functions are used.  This variable is
FALSE by default.
