CMAKE_MINIMUM_REQUIRED_VERSION
------------------------------

Version specified to cmake_minimum_required command

Variable containing the VERSION component specified in the
cmake_minimum_required command.
