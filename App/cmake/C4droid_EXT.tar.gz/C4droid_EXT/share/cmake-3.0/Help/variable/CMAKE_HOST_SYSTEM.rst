CMAKE_HOST_SYSTEM
-----------------

Name of system cmake is being run on.

The same as CMAKE_SYSTEM but for the host system instead of the target
system when cross compiling.
