CMAKE_ARGC
----------

Number of command line arguments passed to CMake in script mode.

When run in -P script mode, CMake sets this variable to the number of
command line arguments.  See also CMAKE_ARGV0, 1, 2 ...
