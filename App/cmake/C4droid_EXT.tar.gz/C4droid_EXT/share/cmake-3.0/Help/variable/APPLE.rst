APPLE
-----

True if running on Mac OS X.

Set to true on Mac OS X.
