CMAKE_<LANG>_FLAGS_MINSIZEREL
-----------------------------

Flags for MinSizeRel build type or configuration.

<LANG> flags used when CMAKE_BUILD_TYPE is MinSizeRel.Short for
minimum size release.
