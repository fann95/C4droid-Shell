CMAKE_COLOR_MAKEFILE
--------------------

Enables color output when using the Makefile generator.

When enabled, the generated Makefiles will produce colored output.
Default is ON.
