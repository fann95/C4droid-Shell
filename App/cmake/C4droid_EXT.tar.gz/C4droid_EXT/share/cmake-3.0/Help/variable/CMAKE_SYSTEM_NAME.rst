CMAKE_SYSTEM_NAME
-----------------

Name of the OS CMake is building for.

This is the name of the operating system on which CMake is targeting.
On systems that have the uname command, this variable is set to the
output of uname -s.  Linux, Windows, and Darwin for Mac OS X are the
values found on the big three operating systems.
