COMPILE_FLAGS
-------------

Additional flags to be added when compiling this source file.

These flags will be added to the list of compile flags when this
source file builds.  Use COMPILE_DEFINITIONS to pass additional
preprocessor definitions.
