HEADER_FILE_ONLY
----------------

Is this source file only a header file.

A property on a source file that indicates if the source file is a
header file with no associated implementation.  This is set
automatically based on the file extension and is used by CMake to
determine if certain dependency information should be computed.
