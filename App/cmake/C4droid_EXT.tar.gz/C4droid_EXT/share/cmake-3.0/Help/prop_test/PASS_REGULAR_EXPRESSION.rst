PASS_REGULAR_EXPRESSION
-----------------------

The output must match this regular expression for the test to pass.

If set, the test output will be checked against the specified regular
expressions and at least one of the regular expressions has to match,
otherwise the test will fail.
